﻿internal class Program
{
    private static void Main(string[] args)
    {
        // Ejercicio 1 
        Console.WriteLine("Ejercicio 1:");
        Console.WriteLine("Ingrese un valor positivo");
        int v = Convert.ToInt32(Console.ReadLine());
        int n = 1;
        Console.WriteLine("");
        Console.WriteLine("Valores uno a uno: ");
        while (n<=v)
        {
            Console.WriteLine(n);
            n++;
        }
       
        Console.WriteLine("");
        Console.WriteLine("Presione enter para continuar");
        Console.WriteLine("");
        Console.ReadKey();
        //Ejercicio 2
        Console.WriteLine("Ejercicio 2");
        char valor = 's';
        int num = 0;
        int suma = 0;
        int promedio = 0;
        while (valor == 's')
        {
            Console.WriteLine("Ingrese un número");
            num = Convert.ToInt32(Console.ReadLine());
            suma = num + suma;
            Console.WriteLine("Suma = " + suma);
            Console.WriteLine("Desea ingresar otro número? s=si y n=no");
            valor = Convert.ToChar(Console.ReadLine());
            promedio++;
        }
        int prom = suma / promedio;
        Console.WriteLine("promedio = " + prom);
        Console.WriteLine("");
        Console.WriteLine("Presione enter para continuar");
        Console.WriteLine("");
        Console.ReadKey();

        // ejercicio 3
        Console.WriteLine("Ejercicio 3: ");
        Console.WriteLine("Nota: Si ya no desea agregar productos asignarle un valor de -1 al siguiente producto");
        Console.WriteLine("Escriba el valor del producto");
        int vp = Convert.ToInt32(Console.ReadLine());
        int total = 0;
        int cantidad = 0;
        int ct = 0;
        while (vp != -1)
        {
            
            Console.WriteLine("Ingrese la cantidad del producto");
            cantidad = Convert.ToInt32(Console.ReadLine());
            int vpp = vp * cantidad;
            total = vpp + total;
            Console.WriteLine("Escriba el valor del siguiente producto: ");
            vp = Convert.ToInt32(Console.ReadLine());
            int cp = cantidad * 1;
            ct = cp+ct; 
        }
        int pt = ct; 
        Console.WriteLine("Debe pagar: " + total + "por " + pt + "Productos");

        Console.ReadKey();
    }
}