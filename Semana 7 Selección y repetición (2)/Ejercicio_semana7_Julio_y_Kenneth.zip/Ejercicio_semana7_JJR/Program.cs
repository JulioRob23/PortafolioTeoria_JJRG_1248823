﻿using System.Diagnostics.CodeAnalysis;

internal class Program
{
    private static void Main(string[] args)
    {
        // Julio Javier Robles - 1248823
        // Kenneth Josue Castillo - 1120623
        // ejercicio 1
       
        int suma = 0;
        for (int cant = 1; cant <= 100; cant++)
        {
            Console.WriteLine("Ingrese un número");
            int n = Convert.ToInt32(Console.ReadLine());
            suma = n + suma;

        }
        Console.WriteLine("La suma es:" + suma);
        Console.ReadKey();

        // ejercicio 2
       
        double estatura;
        int n1 = 0;
        double suma2 = 0;
        char respuesta;
        do
        {
            Console.WriteLine("Ingrese estatura");
            estatura = Convert.ToDouble(Console.ReadLine());
            suma2 = suma2 + estatura; //acumulador 
           n1 ++;

            Console.WriteLine("Desea ingresar otra estatura? s=si, n=no");
            respuesta = Convert.ToChar(Console.ReadLine());

        } while (respuesta == 's');
        double promedio; 
        promedio = suma2 / n1;
        Console.WriteLine("El promedio es: " + promedio);
    }

}