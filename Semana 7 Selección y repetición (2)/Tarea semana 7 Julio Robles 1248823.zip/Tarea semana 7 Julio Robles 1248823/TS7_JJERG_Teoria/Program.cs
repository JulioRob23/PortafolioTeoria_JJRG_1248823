﻿using System.Diagnostics.CodeAnalysis;

internal class Program
{
    private static void Main(string[] args)
    {
        // Ejercicio 1 
        Console.WriteLine("Ejercicio 1: ");
        Console.WriteLine("Porfavor ingrese 10 números");
        double n1 = Convert.ToDouble(Console.ReadLine());
        if (n1 == 0)
        {
            Console.WriteLine("Porfavor ingrese un número diferente a 0");
            n1 = Convert.ToDouble(Console.ReadLine());
        }
        double n2 = Convert.ToDouble(Console.ReadLine());
        if (n2 == 0)
        {
            Console.WriteLine("Porfavor ingrese un número diferente a 0");
            n2 = Convert.ToDouble(Console.ReadLine());
        }
        double n3 = Convert.ToDouble(Console.ReadLine());
        if (n3 == 0)
        {
            Console.WriteLine("Porfavor ingrese un número diferente a 0");
            n3 = Convert.ToDouble(Console.ReadLine());
        }
        double n4 = Convert.ToDouble(Console.ReadLine());
        if (n4 == 0)
        {
            Console.WriteLine("Porfavor ingrese un número diferente a 0");
            n4 = Convert.ToDouble(Console.ReadLine());
        }
        double n5 = Convert.ToDouble(Console.ReadLine());
        if (n5 == 0)
        {
            Console.WriteLine("Porfavor ingrese un número diferente a 0");
            n5 = Convert.ToDouble(Console.ReadLine());
        }
        double n6 = Convert.ToDouble(Console.ReadLine());
        if (n6 == 0)
        {
            Console.WriteLine("Porfavor ingrese un número diferente a 0");
            n6 = Convert.ToDouble(Console.ReadLine());
        }
        double n7 = Convert.ToDouble(Console.ReadLine());
        if (n7 == 0)
        {
            Console.WriteLine("Porfavor ingrese un número diferente a 0");
            n7 = Convert.ToDouble(Console.ReadLine());
        }
        double n8 = Convert.ToDouble(Console.ReadLine());
        if (n8 == 0)
        {
            Console.WriteLine("Porfavor ingrese un número diferente a 0");
            n8 = Convert.ToDouble(Console.ReadLine());
        }
        double n9 = Convert.ToDouble(Console.ReadLine());
        if (n9 == 0)
        {
            Console.WriteLine("Porfavor ingrese un número diferente a 0");
            n9 = Convert.ToDouble(Console.ReadLine());
        }
        double n10 = Convert.ToDouble(Console.ReadLine());
        if (n10 == 0)
        {
            Console.WriteLine("Porfavor ingrese un número diferente a 0");
            n10 = Convert.ToDouble(Console.ReadLine());
        }
        double suma = n1 + n2 + n3 + n4 + n5 + n6 + n7 + n8 + n9 + n10;
        double promedio = suma / 10;
        Console.WriteLine("El promedio es: " + promedio);

        Console.WriteLine("");
        Console.WriteLine("Presione enter para continuar");
        Console.WriteLine("");
        Console.ReadKey();
        // Ejercicio 2}
        Console.WriteLine("Números primos:");

        int num = 2;
        int cantidad = 0;
        int residuo = 0;
        while (cantidad<10)
        {
            
            for (int i  = 1; i <= num; i++)
            {
                if (num % i ==0)
                {
                    residuo++;
                }
                if (residuo > 2)
                {
                    break;
                }

                
            }
            if (residuo == 2)
            {
                Console.WriteLine(num);
                cantidad ++;

            }
            
            residuo = 0;
            num++;

        }
        
    }
}