﻿using System;

class Program
{
    static void Main()
    {
        //Pablo Andres Bocel Morales, Jose Ricardo Guerra Morales, Christopher Javier Yuman Valdez
        double numero = 0;
        
        double suma = 0;
        double cont = 0;

        while (cont <= 11)
        {
            Console.WriteLine("Ingrese su ahorro");
            numero = Convert.ToDouble(Console.ReadLine());

            if (numero > 0)
            {
                suma = suma + numero;
                cont++;
                Console.WriteLine("El ahorro que tiene acumulado es:" + suma);

            }
            else
            {
                Console.WriteLine("Ingrese un numero mayor a 0");

            }

        }

     
        Console.ReadLine();
    }
}