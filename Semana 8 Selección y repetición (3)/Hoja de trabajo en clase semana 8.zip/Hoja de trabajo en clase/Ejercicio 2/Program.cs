﻿internal class Program
{
    private static void Main(string[] args)
    {
        double ventas = 0;
        char respuesta;
        int cont = 0;
        int cont2 = 0;
        int cont3 = 0;
        double suma = 0;
        double sum1 = 0, sum2 = 0, sum3 = 0;
        /*José Ricardo Guerra Morales 1234123, Pablo Andres Bocel Morales 1109623, Christopher Javier Yuman Valdez 1160223*/

        do
        {
            Console.Write("\nIngrese venta realizada "); ventas = Convert.ToInt32(Console.ReadLine());
            Console.Write("Desea ingresar otra venta? ");
            respuesta = Convert.ToChar(Console.ReadLine());
            suma = suma + ventas;

            if (ventas > 1300)
            {
                cont++;
                sum1 = sum1 + ventas;
            }
            else if (ventas > 300 && ventas < 1300)
            {
                cont2++;
                sum2 = sum2 + ventas;
            }
            else if (ventas < 300)
            {
                cont3++;
                sum3= sum3 + ventas;
            }

        } while (respuesta == 's');

        Console.WriteLine("La cantidad de montos mayores a 1300 es: " + cont);
        Console.WriteLine("La cantidad de montos mayores a 300 y menores a 1300 es: " + cont2);
        Console.WriteLine("La cantidad de montos menores a 300 es: " + cont3);

        Console.WriteLine("\nLa suma total de las ventas es: " + suma);
        Console.WriteLine("La suma de las ventas mayores a 1300 es: " + sum1);
        Console.WriteLine("La suma de las ventas mayores a 300 y menores a 1300 es: " + sum2);
        Console.WriteLine("La suma de las ventas menores  a 300 es: " + sum3);

    }
}