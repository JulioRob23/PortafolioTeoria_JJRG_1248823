﻿internal class Program
{
    private static void Main(string[] args)
    {
        // grupo: los guapos y kenneth - Julio Robles, Ricardo Guerra y Kenneth Castillo
        Console.WriteLine("Ejercicio 3");
        Console.WriteLine("Dinero en la caja registradora:");
        double suma = 0;
        double uno = 0;
        double cinco = 0;
        double diez = 0;
        double veinte = 0;
        double cincuenta = 0;
        double cien = 0;
        double doscientos = 0;
        double centavo = 0;
        double cincoc = 0;
        double diezc = 0;
        double veinticincoc = 0;
        double cincuentac = 0;
        double quetzal = 0;
        Console.WriteLine("Billetes:");
        Console.WriteLine("Ingrese la cantidad de billetes de 1 quetzal:");
            uno = Convert.ToDouble(Console.ReadLine());
        uno = uno * 1; 
        suma = suma +uno;
        Console.WriteLine("Ingrese la cantidad de billetes de 5 quetzales:");
            cinco = Convert.ToDouble(Console.ReadLine());
        cinco = cinco * 5;
        suma = suma + cinco;
        Console.WriteLine("Ingrese la cantidad de billetes de 10 quetzales:");
            diez = Convert.ToDouble(Console.ReadLine());
        diez = diez * 10;
        suma = suma + diez;
        Console.WriteLine("Ingrese la cantidad de billetes de 20 quetzales:");
            veinte = Convert.ToDouble(Console.ReadLine());
        veinte = veinte * 20;
        suma = suma + veinte;
        Console.WriteLine("Ingrese la cantidad de billetes de 50 quetzales:");
            cincuenta = Convert.ToDouble(Console.ReadLine());
        cincuenta = cincuenta * 50;
        suma = suma + cincuenta;
        Console.WriteLine("Ingrese la cantidad de billetes de 100 quetzales:");
            cien = Convert.ToDouble(Console.ReadLine());
        cien = cien * 100;
        suma = suma + cien;
        Console.WriteLine("Ingrese la cantidad de billetes de 200 quetzales:");
            doscientos = Convert.ToDouble(Console.ReadLine());
        doscientos = doscientos * 200;
        suma = suma + doscientos;
        Console.WriteLine("Monedas:");
        Console.WriteLine("Ingrese la cantidad de monedas de 1 centavo:");
        centavo = Convert.ToDouble(Console.ReadLine());
        centavo = centavo * 0.01;
        suma = suma + centavo;
        Console.WriteLine("Ingrese la cantidad de monedas de 5 centavos:");
        cincoc = Convert.ToDouble(Console.ReadLine());
        cincoc = cincoc * 0.05;
        suma = suma + cincoc;
        Console.WriteLine("Ingrese la cantidad de monedas de 10 centavos:");
        diezc = Convert.ToDouble(Console.ReadLine());
        diezc = diezc * 0.10;
        suma = suma + diezc;
        Console.WriteLine("Ingrese la cantidad de monedas de 25 centavos:");
        veinticincoc = Convert.ToDouble(Console.ReadLine());
        veinticincoc = veinticincoc * 0.25;
        suma = suma + veinticincoc;
        Console.WriteLine("Ingrese la cantidad de monedas de 50 dentavos:");
        cincuentac = Convert.ToDouble(Console.ReadLine());
        cincuentac = cincuentac * 0.50;
        suma = suma + cincuentac;
        Console.WriteLine("Ingrese la cantidad de modenas de 1 quetzal:");
        quetzal = Convert.ToDouble(Console.ReadLine());
        quetzal = quetzal * 1;
        suma = suma + quetzal;

       

        Console.WriteLine("El total de la caja registradora es de Q" + suma);

    }
}