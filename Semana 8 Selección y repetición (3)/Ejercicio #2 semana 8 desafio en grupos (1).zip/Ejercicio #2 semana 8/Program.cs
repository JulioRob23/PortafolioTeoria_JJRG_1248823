﻿using System.Diagnostics.CodeAnalysis;

internal class Program
{
    private static void Main(string[] args)
    {
        /*Grupo: Los guapos y kenneth, Integrantes: José Ricardo Guerra Morales, Julio Javier Robles Garcia, KENNETH JOSUÉ CASTILLO WONG,*/
        int empleados = 0;
        int horas = 0;
        int dias = 0;
        double ph = 0, pd = 0, salario = 0;
        double suma = 0;
        double Thoras = 0;
        Console.WriteLine("----- EJERCICIO 2 -----");
        Console.Write("\nIngrese número de empleados: "); empleados = Convert.ToInt32(Console.ReadLine());
        Console.WriteLine("");
        for (int i = 1; i <= empleados; i++)
        {
            Console.WriteLine("----- EMPLEADO ----- " + i);
            Console.Write("Ingrese número de días trabajados: "); dias = Convert.ToInt32(Console.ReadLine());
            Console.Write("Ingrese pago por hora "); 
            ph = Convert.ToDouble(Console.ReadLine());

            for (int j = 1; j <= dias; j++)
            {
                Console.WriteLine("Ingrese horas trabajadas en el día " + j);
                horas = Convert.ToInt32(Console.ReadLine());
                salario += horas * ph;

            }
            Console.WriteLine("El total a pagar al empleado " + i + " es " + salario);
            suma = suma + salario;
        }
   
        Console.WriteLine("El total a pagar por los" + empleados +" empleados" +" es de: " + suma);
        

    }
}