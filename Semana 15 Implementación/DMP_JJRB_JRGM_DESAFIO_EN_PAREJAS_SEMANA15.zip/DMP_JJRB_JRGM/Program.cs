﻿using System.Runtime.Intrinsics.X86;

internal class Program
{
    private static void Main(string[] args)
    {
        //Ejercicio en clase Julio Javier Robles Garcia y José Ricardo Guerra Morales"
        int num = 0;
        bool vn = true;
        while (vn)
        {
            Console.WriteLine("Ingrese la cantidad de equipos en el torneo:");
            
            string x = Console.ReadLine();
            if (int.TryParse(x, out num))
            {
                vn = false; 
            }
            else
            {
                // El valor ingresado es un entero
                Console.WriteLine("Este dato no es válido");
            }
        }
        bool vnombres = true;
        string[] nombres = new string[num];
        for(int i = 0;i < nombres.Length; i++)
        {
            do
            {
                Console.WriteLine("Ingrese nombre del equipo:");
                nombres[i] = Console.ReadLine();

                for (int d = 0; d < i; d++)
                {
                    if (nombres[d] == nombres[i])
                    {
                        vnombres = false;
                        break;
                    }
                    else
                    {
                        vnombres = true;
                    }
                }

                if (vnombres)
                {

                }
                else
                {
                    Console.WriteLine("Este equipo ya existe, porfavor ingrese otro");
                }
            } while (vnombres == false);

            
        }
        int[,] valores = new int[num, 6];
        for(int i = 0;i < num; i++)
        {
            for(int j = 0; j < 6; j++) 
            {
                Random n = new Random();
                valores[i,j]= n.Next(1,15);
                
            }
        }

        for(int x = 0; x < num; x++)
        {
            Console.Write(nombres[x]);
            for (int b = 0; b < 6; b++)
            {
                Console.Write(" | " + valores[x,b] + " | " );
            }
            Console.WriteLine("");
        }
        int s = 0;
        int v = 0;
        for (int z= 0; z < valores.GetUpperBound(0) + 1; z++)
        {
            if (valores[z,4] > v) 
            { 
                v = valores[z,4];
                s = z;
            }
        }
        int s2 = 0;
        int v2 = 15;
        for (int z = 0; z < valores.GetUpperBound(0) + 1; z++)
        {
            if (valores[z, 5] < v2)
            {
                v2 = valores[z, 5];
                s2 = z;
            }
        }
        double promedio = 0;
        for (int u = 0; u < valores.GetUpperBound(0) + 1 ; u++)
        {
            promedio = promedio + valores[u,0];
        }
        promedio = promedio / num;

        int s3 = 0;
        int v3 = 0;
        for (int z = 0; z < valores.GetUpperBound(0) + 1; z++)
        {
            if (valores[z, 1] > v3)
            {
                v3 = valores[z, 1];
                s3 = z;
            }
        }

        double sumgf = 0;
        for (int u = 0; u < valores.GetUpperBound(0) + 1; u++)
        {
            sumgf = sumgf + valores[u, 4];
        }
        double sumgc = 0;
        for (int u = 0; u < valores.GetUpperBound(0) + 1; u++)
        {
            sumgc = sumgc + valores[u, 5];
        }

        int s4 = 0;
        int v4 = 0;
        for (int z = 0; z < valores.GetUpperBound(0) + 1; z++)
        {
            if (valores[z, 2] > v4)
            {
                v4 = valores[z, 2];
                s4 = z;
            }
        }

        double promediogf = 0;
        for (int u = 0; u < valores.GetUpperBound(0) + 1; u++)
        {
            promediogf = promediogf + valores[u, 4];
        }
        promediogf = promediogf / num;

        Console.WriteLine("Equipo con mas goles a favor " + nombres[s]);
        Console.WriteLine("Equipo con menos goles en contra " + nombres[s2]);
        Console.WriteLine("Promedio de partidos jugados " + promedio);
        Console.WriteLine("Equipo con mas partidos ganados " + nombres[s3]);
        Console.WriteLine("Total goles a favor " + sumgf);
        Console.WriteLine("Total goles en contra " + sumgc);
        Console.WriteLine("Equipo con más partidos empatados " + nombres[s4]);
        Console.WriteLine("Equipos que están sobre el promedio de goles a favor  " );
        for(int f = 0; f < valores.GetUpperBound(0) + 1; f++)
        {
            if (valores[f,4] > promediogf)
            {
                Console.Write(nombres[f] + " ");
            }
        }

        Console.ReadKey();
    }
}