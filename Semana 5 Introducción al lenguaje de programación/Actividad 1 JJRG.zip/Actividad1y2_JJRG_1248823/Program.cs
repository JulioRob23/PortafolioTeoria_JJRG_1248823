﻿internal class Program
{
    private static void Main(string[] args)
    {
        double pi = Math.PI;
        double r = 10
        Console.WriteLine(pi);
        Console.WriteLine(r);
    }
}