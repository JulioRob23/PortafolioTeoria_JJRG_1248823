﻿using System;
using System.Data;

class Temperatura
{
    static void Main()
    {
        double[,] temperaturas = new double[7, 2];
        string[] dias = new string[7];
        dias[0] = "Lunes";
        dias[1] = "Martes";
        dias[2] = "Miércoles";
        dias[3] = "Jueves";
        dias[4] = "Viernes";
        dias[5] = "Sabado";
        dias[6] = "Domingo";
        for (int i = 0; i < 7; i++)
        {
            for (int f = 0; f < 2; f++)
            {
                Random r = new Random();
                temperaturas[i, f] = r.Next(15, 32);
            }
        }
        double promediotresd = 0;
        for (int l = 4; l < 7; l++)
        {
            for (int m = 0; m < 1; m++)
            {
                promediotresd = promediotresd + temperaturas[l, m];
            }
        }
        promediotresd = promediotresd / 3;
        double mayor = 0;
        int h = 0, h2 = 0;
        for (h = 0; h < 7; h++)
        {
            if (mayor < temperaturas[h, 1])
            {
                mayor = temperaturas[h, 1];
                h2 = h;
            }
        }
        double menor = 32;
        int g = 0, g2 = 0;
        for (g = 0; g < 7; g++)
        {
            if (menor > temperaturas[g, 0])
            {
                menor = temperaturas[g, 0];
                g2 = g;
            }
        }
        double dm30 = 0;
        int x = 0;
        for (x = 0; x < 7; x++)
        {
            if (temperaturas[x, 0] < 30 && temperaturas[x, 1] < 30)
            {
                dm30 = dm30 + 1;
            }

        }
        double promediotard = 0;
        for(int n = 0; n < 7; n++)
        {
            for (int j = 1; j < 2; j++)
            {
                promediotard = promediotard + temperaturas[n, j];
            }
        }
        promediotard = promediotard / 7;
        string cal = "";
        if (promediotard > 30)
        {
            cal = "Si es temporada calurosa";
        }
        else
        {
            cal = "No es temporada calurosa";
        }
        Console.WriteLine("        M - T ");
        for (int a = 0; a < 7; a++)
        {
            Console.Write(dias[a] + "  ");
            for (int b = 0; b < 2; b++)
            {
                Console.Write(temperaturas[a, b] + " ");
            }
            Console.WriteLine();
        }
        Console.WriteLine("Promedio ultimos tres días: " + promediotresd);
        Console.WriteLine("Día mas caluroso por la tarde: " + dias[h2]);
        Console.WriteLine("Día menos caluroso por la mañana: " + dias[g2]);
        Console.WriteLine("Cantidad de días con temperatura menor a 30 grados por la mañana y tarde: " +dm30);
        Console.WriteLine(cal);
        Console.ReadKey();

        // Preguntas: 
        // ¿Qué representan las filas?
        // Las filas representan los días de la semana 
        //¿Qué representan las columnas?
        // Representan las temperaturas en la mañana y tarde
        // ¿Por qué escogieron este tipo de dato?
        /* Elegimos el tipo double porque al momento de realizar operaciones con los datos
        generalmente se generan decimales, mas que todo en los promedios */
    }
}