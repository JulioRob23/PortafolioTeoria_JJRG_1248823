﻿using System;
class Program
    {
        static void Main()
        {
            double[,] notas = new double[5, 6];
        string[] nombres = new string[5];

            for (int f = 0; f < 5; f++)
            {
                Console.WriteLine("Ingrese nombre");
                nombres[f] = Console.ReadLine();

                for (int c = 0; c < 6; c++)
                {
                    Random r = new Random();
                    notas[f, c] = r.Next(1, 100);
                }
            }

            

        double[] promedioest = new double[5];
        for (int f3 = 0; f3< 5; f3++)
        {
            double promedio = 0;
            for(int c3 = 0; c3<6; c3++)
            {
                promedio = promedio + notas[f3, c3];
            }
            promedio = promedio / 6;
            promedioest[f3] = promedio;

           
        }
        double[] promedioasig = new double[6];
        for (int f4 = 0; f4 < 6; f4++)
        {
            double promedio2 = 0;
            for (int c4 = 0; c4 < 5; c4++)
            {
                promedio2 = promedio2 + notas[c4, f4];
            }
            promedio2 = promedio2 / 5;
            promedioasig[f4] = promedio2;
        }

        for (int f2 = 0; f2 < 5; ++f2)
        {
            Console.Write(nombres[f2] + " |");
            for (int c2 = 0; c2 < 6; c2++)
            {
                Console.Write(notas[f2, c2] + "|");
            }
            Console.Write(" Promedio " + promedioest[f2]);
            Console.WriteLine();
        }
        Console.WriteLine("");
        for (int n = 0; n < 6; n++)
        {
            Console.WriteLine("Promedio asignatura " + (n + 1) + " " + promedioasig[n]);
        }
    }


    }
